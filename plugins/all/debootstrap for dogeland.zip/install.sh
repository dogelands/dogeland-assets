ln -s bin/pkgdetails_arm bin/pkgdetails_arm64
ln -s bin/pkgdetails_x86 bin/pkgdetails_x86_64
ln -s bin/pkgdetails_$platform bin/pkgdetails