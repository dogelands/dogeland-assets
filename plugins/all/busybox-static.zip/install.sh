echo "*Busybox Static Installer*"
echo "将要安装: 适用于 $platform 的Busybox"
sleep 1
echo "- 正在移除旧版文件"
rm bin/busybox
echo "- 正在安装"
cp common/busybox_$platform bin/busybox
echo "- 正在设置权限"
chmod 0777 bin/busybox
echo "- 正在清除缓存"
rm -rf common
echo "- 已完成"