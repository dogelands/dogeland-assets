#
# Dogeland Plugin Installer
#
echo "正在设置PulseAudio.."
ln -s ./bin/pacat ./bin/pamon
ln -s ./bin/pacat ./bin/paplay
ln -s ./bin/pacat ./bin/parec
ln -s ./bin/pacat ./bin/parecord
ln -s ./lib/pulse-13.0/modules/libcli.so ./libcli.so
ln -s ./lib/pulse-13.0/modules/libprotocol-cli.so ./libprotocol-cli.so
ln -s ./lib/pulse-13.0/modules/libprotocol-http.so ./libprotocol-http.so
ln -s ./lib/pulse-13.0/modules/libprotocol-native.so ./libprotocol-native.so
ln -s ./lib/pulse-13.0/modules/libprotocol-simple.so ./libprotocol-simple.so
ln -s ./lib/pulseaudio/libpulsecommon-13.0.so ./libpulsecommon-13.0.so
ln -s ./lib/pulseaudio/libpulsecore-13.0.so ./libpulsecore-13.0.so
ln -s ./lib/pulse-13.0/modules/librtp.so ./librtp.so
echo "安装完成"