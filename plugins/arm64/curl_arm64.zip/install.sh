chmod -R 0777 $TOOLKIT/curl
